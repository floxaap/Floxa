'use client';
import Link from 'next/link';
import { useI18n } from '@/i18n';
export default function Splash() {
  const { t } = useI18n();
  return (
    <main className="splash">
      <div className="moon" aria-hidden /><div className="lake" aria-hidden />
      <h1 className="logo">FLOXAAP</h1>
      <p className="tag">{t('common.tagline')}</p>
      <div className="act-in">
        <Link href="/auth?mode=register" className="gold-btn">{t('common.getStarted')}</Link>
        <Link href="/auth" className="ghost" style={{ textAlign: 'center' }}>{t('common.signIn')}</Link>
      </div>
    </main>
  );
}
