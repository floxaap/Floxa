'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link'; import { useParams, useRouter } from 'next/navigation'; import { doc, onSnapshot } from 'firebase/firestore';
import AuthGuard, { useUser } from '@/components/AuthGuard'; import { db } from '@/lib/firebase'; import type { Conv } from '@/lib/chat';
import { addMember, leaveGroup, makeAdmin, removeMember, renameGroup, reportGroup } from '@/lib/groups'; import { useI18n } from '@/i18n';
const box = { background: 'var(--card)', border: '1px solid var(--line)', borderRadius: 12, padding: 10, textAlign: 'start' as const, flex: 1 };
function Info() {
  const { id } = useParams<{ id: string }>(); const { t } = useI18n(); const u = useUser(); const r = useRouter();
  const [c, setC] = useState<Conv | null>(null), [m, setM] = useState(''), [nm, setNm] = useState(''), [msg, setMsg] = useState(''), [err, setErr] = useState('');
  useEffect(() => onSnapshot(doc(db, 'conversations', id), s => { if (s.exists()) { const d = { ...(s.data() as any), id } as Conv; setC(d); setNm(x => x || d.name || ''); } }, () => r.replace('/messages')), [id]); // eslint-disable-line
  if (!c) return <p className="sub" style={{ padding: 24 }}>{t('common.loading')}</p>;
  const admin = !!c.admins?.includes(u.uid);
  const run = async (f: () => Promise<unknown>) => { setErr(''); setMsg(''); try { await f(); } catch (e: any) { setErr(['notFound', 'maxMembers'].includes(e.message) ? t(e.message === 'notFound' ? 'chat.notFound' : 'chat.maxMembers') : t('auth.errors.generic')); } };
  return (<div className="shell" style={{ padding: 16 }}>
    <Link href={'/messages/' + id} className="flip" style={{ color: 'var(--gold-l)', fontSize: 22 }} aria-label={t('chat.back')}>←</Link>
    <h1 dir="auto" style={{ fontSize: '1.3rem', marginBlock: 12 }}>{c.name}</h1>
    {err && <p className="err" role="alert">{err}</p>}{msg && <p className="ok">{msg}</p>}
    {admin && <div className="row" style={{ marginBlockEnd: 12 }}><input style={box} dir="auto" maxLength={60} value={nm} onChange={e => setNm(e.target.value)} /><button className="ghost" onClick={() => run(() => renameGroup(id, nm))}>{t('chat.rename')}</button></div>}
    <h2 className="sub">{t('chat.members')} ({c.members.length})</h2>
    {c.members.map(uid => { const i = c.memberInfo[uid]; return (<div key={uid} className="row" style={{ paddingBlock: 8 }}>
      <Link href={'/profile/' + uid} className="row" style={{ flex: 1, textDecoration: 'none', color: 'inherit' }}><b dir="auto">{i?.name}</b><span className="sub" dir="ltr" style={{ unicodeBidi: 'isolate' }}>@{i?.username}</span>{c.admins?.includes(uid) && <span className="sub">★ {t('chat.admin')}</span>}</Link>
      {admin && uid !== u.uid && <>{!c.admins?.includes(uid) && <button className="ghost" onClick={() => run(() => makeAdmin(id, uid))}>{t('chat.makeAdmin')}</button>}<button className="ghost" onClick={() => run(() => removeMember(id, uid))}>{t('chat.remove')}</button></>}</div>); })}
    {admin && <div className="row" style={{ marginBlock: 12 }}><input style={{ ...box, direction: 'ltr' }} value={m} placeholder={t('chat.memberPh')} onChange={e => setM(e.target.value)} /><button className="ghost" onClick={() => run(async () => { await addMember(c, m); setM(''); })}>{t('chat.add')}</button></div>}
    <div className="row" style={{ marginBlockStart: 20 }}><button className="ghost" onClick={() => run(async () => { await reportGroup(id, u.uid); setMsg(t('chat.reported')); })}>{t('chat.report')}</button>
      <button className="err" onClick={() => run(async () => { await leaveGroup(c, u.uid); r.replace('/messages'); })}>{t('chat.leave')}</button></div></div>);
}
export default function Page() { return <AuthGuard><Info /></AuthGuard>; }
