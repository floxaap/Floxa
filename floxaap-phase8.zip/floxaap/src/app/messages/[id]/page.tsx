'use client';
import { useEffect, useRef, useState } from 'react';
import Link from 'next/link'; import { useParams } from 'next/navigation';
import { collection, doc, limitToLast, onSnapshot, orderBy, query, Timestamp, getDoc } from 'firebase/firestore';
import { useCall } from '@/components/CallHost'; import AuthGuard, { useUser } from '@/components/AuthGuard';
import { auth, db } from '@/lib/firebase'; import { Conv, deleteMessage, editMessage, markRead, Msg, otherOf, sendMessage, status } from '@/lib/chat'; import { useI18n } from '@/i18n';
const TICK: Record<string, string> = { sending: '🕓', sent: '✓', delivered: '✓✓', read: '✓✓', failed: '!' };
function Chat() {
  const { id } = useParams<{ id: string }>(); const { t, lang } = useI18n(); const u = useUser(); const { start } = useCall();
  const [conv, setConv] = useState<Conv | null>(null); const [msgs, setMsgs] = useState<Msg[]>([]); const [failed, setFailed] = useState<{ k: number; text: string; replyTo: Msg['replyTo'] }[]>([]);
  const [text, setText] = useState(''); const [reply, setReply] = useState<Msg | null>(null); const [editing, setEditing] = useState<Msg | null>(null); const [menu, setMenu] = useState<string | null>(null); const end = useRef<HTMLDivElement>(null);
  useEffect(() => onSnapshot(doc(db, 'conversations', id), s => s.exists() && setConv({ ...(s.data() as any), id }), () => {}), [id]);
  useEffect(() => onSnapshot(query(collection(db, 'conversations', id, 'messages'), orderBy('createdAt', 'asc'), limitToLast(100)), { includeMetadataChanges: true }, s => {
    const rows = s.docs.map(d => { const x = d.data({ serverTimestamps: 'estimate' }); return { ...(x as any), id: d.id, createdAt: (x.createdAt as Timestamp).toDate(), pending: d.metadata.hasPendingWrites } as Msg; });
    setMsgs(rows); const unread = rows.filter(m => m.senderId !== u.uid && !m.readBy.includes(u.uid) && !m.pending).map(m => m.id);
    if (unread.length && document.visibilityState === 'visible') markRead(id, u.uid, unread).catch(() => {});
  }), [id, u.uid]);
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }); }, [msgs.length, failed.length]);
  const other = conv && !conv.isGroup ? otherOf(conv, u.uid) : ''; const others = conv ? conv.members.filter(m => m !== u.uid) : []; const grp = !!conv?.isGroup; const o = conv?.memberInfo[other];
  async function send(body = text, rt = reply ? { id: reply.id, text: reply.text.slice(0, 80) } : null, k = Date.now()) {
    const v = body.trim(); if (!v || !conv) return;
    if (editing) { try { await editMessage(id, editing.id, v); } catch {} setEditing(null); setText(''); return; }
    setText(''); setReply(null); setFailed(f => f.filter(x => x.k !== k));
    try { await sendMessage(id, u.uid, others, v, rt, auth.currentUser?.displayName ?? ''); } catch { setFailed(f => [...f, { k, text: v, replyTo: rt }]); }
  }
  const fmt = (d: Date) => new Intl.DateTimeFormat(lang, { hour: 'numeric', minute: '2-digit' }).format(d);
  return (<div className="shell" style={{ display: 'flex', flexDirection: 'column', paddingBlockEnd: 0, blockSize: '100dvh' }}>
    <header className="top"><div className="row"><Link href="/messages" aria-label={t('chat.back')} className="flip" style={{ color: 'var(--gold-l)', fontSize: 22 }}>←</Link><b dir="auto">{grp ? conv?.name : o?.name}</b>{grp ? <span className="sub">👥 {conv?.members.length}</span> : <span className="sub" dir="ltr" style={{ unicodeBidi: 'isolate' }}>@{o?.username}</span>}</div><span className="row" style={{ gap: 14, fontSize: 20 }}>{grp ? <Link href={'/messages/' + id + '/info'} aria-label={t('chat.groupInfo')}>ⓘ</Link> : <><button aria-label={t('call.voice')} onClick={() => start(other, o?.name ?? '', 'voice')}>📞</button><button aria-label={t('call.video')} onClick={() => start(other, o?.name ?? '', 'video')}>🎥</button></>}</span></header>
    <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 6, padding: '8px 12px' }}>
      {msgs.map(m => { const mine = m.senderId === u.uid, st = mine ? (grp ? (m.pending ? 'sending' : m.readBy.length > 1 ? 'read' : 'sent') : status(m, u.uid, other)) : null; return (
        <div key={m.id} className={'bubble ' + (mine ? 'out' : 'in')}>
          {grp && !mine && <b className="sub" dir="auto">{m.senderName}</b>}
          {m.replyTo && <div className="quote" dir="auto">{m.replyTo.text}</div>}
          <p dir="auto" style={{ textAlign: 'start', lineHeight: 1.55, whiteSpace: 'pre-wrap', opacity: m.deleted ? .6 : 1, fontStyle: m.deleted ? 'italic' : 'normal' }}>{m.deleted ? t('chat.deleted') : m.text}</p>
          <div className="meta"><span>{fmt(m.createdAt)}{m.editedAt && !m.deleted ? ' · ' + t('chat.edited') : ''}</span>{st && <span aria-label={t('chat.status.' + st)} style={{ color: st === 'read' ? '#0b5c3f' : undefined }}>{TICK[st]}</span>}
            {!m.deleted && <button aria-label={t('chat.more')} onClick={() => setMenu(menu === m.id ? null : m.id)}>⋯</button>}</div>
          {menu === m.id && <div className="menu">
            <button onClick={() => { setReply(m); setEditing(null); setMenu(null); }}>{t('chat.reply')}</button>
            <button onClick={() => { navigator.clipboard?.writeText(m.text); setMenu(null); }}>{t('chat.copy')}</button>
            {mine && <button onClick={() => { setEditing(m); setText(m.text); setReply(null); setMenu(null); }}>{t('chat.edit')}</button>}
            {mine && <button onClick={() => { deleteMessage(id, m.id); setMenu(null); }}>{t('chat.delete')}</button>}</div>}
        </div>); })}
      {failed.map(f => <button key={f.k} className="bubble out" style={{ border: '1px solid #ff8a7a' }} onClick={() => send(f.text, f.replyTo, f.k)}><p dir="auto" style={{ textAlign: 'start' }}>{f.text}</p><div className="meta err">! {t('chat.status.failed')} · {t('chat.retry')}</div></button>)}
      <div ref={end} /></div>
    <div style={{ padding: '8px 12px calc(10px + env(safe-area-inset-bottom))', borderBlockStart: '1px solid var(--line)' }}>
      {(reply || editing) && <p className="sub row">{editing ? t('chat.editing') : t('chat.replyingTo')}<button className="ghost" onClick={() => { setReply(null); setEditing(null); setText(''); }}>{t('chat.cancel')}</button></p>}
      <div className="row"><input dir="auto" value={text} maxLength={4000} placeholder={t('chat.typeMsg')} onChange={e => setText(e.target.value)} onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()} style={{ flex: 1, background: 'var(--card)', border: '1px solid var(--line)', borderRadius: 999, padding: '10px 14px', textAlign: 'start' }} />
        <button className="ghost" onClick={() => send()} aria-label={t('chat.send')}><span className="flip" style={{ display: 'inline-block' }}>➤</span></button></div></div>
  </div>);
}
export default function Page() { return <AuthGuard><Chat /></AuthGuard>; }
