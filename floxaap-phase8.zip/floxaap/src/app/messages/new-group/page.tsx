'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import AuthGuard, { useUser } from '@/components/AuthGuard'; import { createGroup } from '@/lib/groups'; import { useI18n } from '@/i18n';
const box = { background: 'var(--card)', border: '1px solid var(--line)', borderRadius: 12, padding: 12, textAlign: 'start' as const, inlineSize: '100%' };
function NewGroup() {
  const { t } = useI18n(); const u = useUser(); const r = useRouter(); const [name, setName] = useState(''), [m, setM] = useState(''), [list, setList] = useState<string[]>([]), [err, setErr] = useState(''), [busy, setBusy] = useState(false);
  const add = () => { const v = m.trim().replace(/^@/, '').toLowerCase(); if (v && !list.includes(v)) setList([...list, v]); setM(''); };
  async function go() { setErr(''); if (!name.trim()) return setErr(t('chat.needName')); if (!list.length) return setErr(t('chat.needMember')); setBusy(true);
    try { r.replace('/messages/' + (await createGroup(u.uid, name, list))); } catch (e: any) { setErr(['notFound', 'needMember', 'maxMembers'].includes(e.message) ? t('chat.' + e.message) : t('auth.errors.generic')); setBusy(false); } }
  return (<div className="shell" style={{ padding: 16 }}><h1 style={{ fontSize: '1.2rem', marginBlock: 12 }}>{t('chat.newGroup')}</h1>
    <input style={box} dir="auto" maxLength={60} value={name} placeholder={t('chat.groupName')} onChange={e => setName(e.target.value)} />
    <div className="row" style={{ marginBlock: 12 }}><input style={{ ...box, direction: 'ltr' }} value={m} placeholder={t('chat.memberPh')} onChange={e => setM(e.target.value)} onKeyDown={e => e.key === 'Enter' && add()} /><button className="ghost" onClick={add}>{t('chat.add')}</button></div>
    <div className="row" style={{ flexWrap: 'wrap', marginBlockEnd: 12 }}>{list.map(x => <button key={x} className="act on" style={{ border: '1px solid var(--line)', borderRadius: 99, padding: '4px 12px' }} dir="ltr" onClick={() => setList(list.filter(y => y !== x))}>@{x} ✕</button>)}</div>
    {err && <p className="err" role="alert">{err}</p>}<button className="gold-btn" disabled={busy} onClick={go}>{busy ? t('common.loading') : t('chat.create')}</button></div>);
}
export default function Page() { return <AuthGuard><NewGroup /></AuthGuard>; }
