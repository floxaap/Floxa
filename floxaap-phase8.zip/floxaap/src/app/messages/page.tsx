'use client';
import { useEffect, useRef, useState } from 'react';
import Link from 'next/link'; import { useRouter } from 'next/navigation';
import { collection, onSnapshot, orderBy, query, Timestamp, where } from 'firebase/firestore';
import AuthGuard, { useUser } from '@/components/AuthGuard'; import BottomNav from '@/components/BottomNav';
import { db } from '@/lib/firebase'; import { Conv, markDelivered, otherOf, startChat } from '@/lib/chat'; import { useI18n } from '@/i18n';
function List() {
  const { t, lang } = useI18n(); const u = useUser(); const r = useRouter();
  const [convs, setConvs] = useState<Conv[]>([]); const [only, setOnly] = useState(false); const [name, setName] = useState(''); const [err, setErr] = useState(''); const done = useRef(new Set<string>());
  useEffect(() => onSnapshot(query(collection(db, 'conversations'), where('members', 'array-contains', u.uid), orderBy('lastAt', 'desc')), s => {
    const rows = s.docs.map(d => { const x = d.data(); return { ...(x as any), id: d.id, lastAt: (x.lastAt as Timestamp | null)?.toDate() } as Conv; });
    setConvs(rows);
    rows.forEach(c => { const l = c.lastMessage; if (l && l.senderId !== u.uid && !done.current.has(l.id)) { done.current.add(l.id); markDelivered(c.id, l.id, u.uid).catch(() => done.current.delete(l.id)); } });
  }, () => setErr(t('auth.errors.generic'))), [u.uid]); // eslint-disable-line
  async function go() { setErr(''); try { r.push('/messages/' + (await startChat(u.uid, name))); } catch (e: any) { setErr(e.message === 'notFound' ? t('chat.notFound') : e.message === 'self' ? t('chat.self') : t('auth.errors.generic')); } }
  const shown = convs.filter(c => !only || (c.unread?.[u.uid] ?? 0) > 0);
  const fmt = (d?: Date) => d ? new Intl.DateTimeFormat(lang, { hour: 'numeric', minute: '2-digit' }).format(d) : '';
  return (<div className="shell"><header className="top"><h1 style={{ fontSize: '1.3rem' }}>{t('chat.title')}</h1><Link href="/messages/new-group" className="ghost">👥 {t('chat.newGroup')}</Link></header>
    <div className="row" style={{ padding: '0 12px 8px' }}>
      <input className="field" style={{ flex: 1, background: 'var(--card)', border: '1px solid var(--line)', borderRadius: 999, padding: '10px 14px', textAlign: 'start' }} dir="auto" value={name} placeholder={t('chat.newChatPh')} onChange={e => setName(e.target.value)} onKeyDown={e => e.key === 'Enter' && go()} />
      <button className="ghost" onClick={go}>{t('chat.start')}</button></div>
    {err && <p className="err" style={{ padding: '0 16px' }} role="alert">{err}</p>}
    <div className="row" style={{ padding: '0 12px' }}>{[false, true].map(v => <button key={String(v)} className={'act' + (only === v ? ' on' : '')} aria-pressed={only === v} onClick={() => setOnly(v)}>{t(v ? 'chat.unread' : 'chat.all')}</button>)}</div>
    {convs.length === 0 && <p className="sub" style={{ padding: 24 }}>{t('chat.empty')}</p>}
    {shown.map(c => { const o = c.isGroup ? { name: '👥 ' + c.name } : c.memberInfo[otherOf(c, u.uid)], n = c.unread?.[u.uid] ?? 0; return (
      <Link key={c.id} href={'/messages/' + c.id} className="row" style={{ padding: '12px 16px', textDecoration: 'none', color: 'inherit' }}>
        <span className="avatar" style={{ display: 'grid', placeItems: 'center', color: 'var(--gold-l)' }}>{(o?.name || '?').slice(0, 1)}</span>
        <div style={{ flex: 1, minInlineSize: 0 }}><b dir="auto">{o?.name}</b><div className="sub" dir="auto" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', textAlign: 'start' }}>{c.lastMessage?.text}</div></div>
        <div style={{ textAlign: 'end' }}><div className="sub">{fmt(c.lastAt)}</div>{n > 0 && <span style={{ background: 'var(--gold)', color: '#1a1108', borderRadius: 99, padding: '1px 8px', fontSize: '.75rem' }}>{new Intl.NumberFormat(lang).format(n)}</span>}</div>
      </Link>); })}
    <BottomNav /></div>);
}
export default function Page() { return <AuthGuard><List /></AuthGuard>; }
