import type { Metadata, Viewport } from 'next';
import { Inter, IBM_Plex_Sans_Arabic } from 'next/font/google';
import { I18nProvider } from '@/i18n';
import CallHost from '@/components/CallHost';
import './globals.css';
const en = Inter({ subsets: ['latin'], variable: '--font-en' });
const ar = IBM_Plex_Sans_Arabic({ subsets: ['arabic'], weight: ['400', '500', '600'], variable: '--font-ar' });
export const metadata: Metadata = { title: 'FLOXAAP' };
export const viewport: Viewport = { themeColor: '#050505', viewportFit: 'cover' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en" dir="ltr" className={`${en.variable} ${ar.variable}`}><body><I18nProvider><CallHost>{children}</CallHost></I18nProvider></body></html>);
}
