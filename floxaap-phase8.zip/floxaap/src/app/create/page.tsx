'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import AuthGuard, { useUser } from '@/components/AuthGuard'; import BottomNav from '@/components/BottomNav';
import { MAX_BYTES, publishPost, publishStory, uploadMedia } from '@/lib/publish'; import { useI18n } from '@/i18n';
function Create() {
  const { t } = useI18n(); const u = useUser(); const r = useRouter();
  const [kind, setKind] = useState<'post' | 'story'>('post'); const [file, setFile] = useState<File | null>(null); const [caption, setCaption] = useState('');
  const [pct, setPct] = useState<number | null>(null); const [err, setErr] = useState(''); const [ok, setOk] = useState(false);
  const preview = file ? URL.createObjectURL(file) : null;
  async function go() {
    setErr('');
    if (kind === 'story' && !file) return setErr(t('home.storyNeedsMedia'));
    if (!file && !caption.trim()) return setErr(t('home.noMedia'));
    if (file && file.size > MAX_BYTES) return setErr(t('home.tooBig'));
    try {
      setPct(0); const url = file ? await uploadMedia(u.uid, file, setPct) : undefined; const type = file?.type.startsWith('video') ? 'video' : 'image';
      if (kind === 'story') await publishStory(u.uid, url!); else await publishPost(u.uid, caption.trim(), url, file ? type : undefined);
      setOk(true); setTimeout(() => r.replace('/home'), 800);
    } catch { setErr(t('home.uploadFail')); setPct(null); }
  }
  const busy = pct !== null && !ok;
  return (<div className="shell">
    <header className="top"><h1 style={{ fontSize: '1.2rem' }}>{t('common.nav.create')}</h1></header>
    <div className="row" style={{ padding: '0 16px 12px' }}>{(['post', 'story'] as const).map(k => <button key={k} className={'act' + (kind === k ? ' on' : '')} aria-pressed={kind === k} onClick={() => setKind(k)} disabled={busy}>{t('home.' + k)}</button>)}</div>
    <label className="card" style={{ display: 'grid', placeItems: 'center', minBlockSize: 200, overflow: 'hidden', cursor: 'pointer' }}>
      {preview ? (file!.type.startsWith('video') ? <video src={preview} className="post-media" muted playsInline /> : <img src={preview} className="post-media" alt="" />) : <span className="sub">{t('home.pickMedia')}</span>}
      <input type="file" accept="image/*,video/*" hidden onChange={e => setFile(e.target.files?.[0] ?? null)} disabled={busy} />
    </label>
    {kind === 'post' && <label className="field" style={{ padding: '0 12px' }}><textarea value={caption} onChange={e => setCaption(e.target.value)} dir="auto" rows={3} placeholder={t('home.captionPh')} maxLength={2000} style={{ background: 'var(--card)', color: 'inherit', border: '1px solid var(--line)', borderRadius: 12, padding: 12, font: 'inherit', textAlign: 'start' }} /></label>}
    <div style={{ padding: '0 12px' }}>
      {err && <p className="err" role="alert">{err}</p>}{ok && <p className="ok">{t('home.published')}</p>}
      {busy && <div className="bar" style={{ marginBlockEnd: 8 }}><i style={{ inlineSize: (pct ?? 0) + '%' }} /></div>}
      <button className="gold-btn" onClick={go} disabled={busy || ok}>{busy ? t('home.publishing', { n: pct ?? 0 }) : t('home.publish')}</button>
    </div><BottomNav /></div>);
}
export default function Page() { return <AuthGuard><Create /></AuthGuard>; }
