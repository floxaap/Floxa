'use client';
import { useCallback, useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import AuthGuard, { useUser } from '@/components/AuthGuard'; import BottomNav from '@/components/BottomNav';
import { addComment, Comment, fetchComments } from '@/lib/comments'; import { useI18n } from '@/i18n';
function Comments() {
  const { id } = useParams<{ id: string }>(); const { t, relTime } = useI18n(); const u = useUser();
  const [list, setList] = useState<Comment[]>([]); const [text, setText] = useState(''); const [to, setTo] = useState<Comment | null>(null); const [err, setErr] = useState(false); const [busy, setBusy] = useState(false);
  const load = useCallback(() => fetchComments(id).then(setList).catch(() => setErr(true)), [id]); useEffect(() => { load(); }, [load]);
  async function send() { if (!text.trim() || busy) return; setBusy(true); setErr(false); try { await addComment(id, u.uid, text, to ? (to.parentId ?? to.id) : null); setText(''); setTo(null); await load(); } catch { setErr(true); } finally { setBusy(false); } }
  const roots = list.filter(c => !c.parentId);
  const item = (c: Comment, reply = false) => (<div key={c.id} style={{ paddingInlineStart: reply ? 36 : 0, marginBlock: 10 }}>
    <div className="sub"><b dir="ltr" style={{ unicodeBidi: 'isolate', color: 'var(--tx)' }}>@{c.username}</b> · {relTime(c.createdAt)}</div>
    <p dir="auto" style={{ textAlign: 'start', lineHeight: 1.6 }}>{c.text}</p>
    <button className="sub" onClick={() => setTo(c)}>{t('home.replyBtn')}</button></div>);
  return (<div className="shell"><header className="top"><h1 style={{ fontSize: '1.2rem' }}>{t('home.comment')}</h1></header>
    <div style={{ padding: '0 16px' }}>
      {list.length === 0 && !err && <p className="sub">{t('home.noComments')}</p>}
      {roots.map(c => [item(c), ...list.filter(r => r.parentId === c.id).map(r => item(r, true))])}
    </div>
    <div style={{ position: 'sticky', insetBlockEnd: 70, background: 'var(--bg)', padding: 12 }}>
      {to && <p className="sub">{t('home.replyTo', { name: '@' + to.username })} <button className="ghost" onClick={() => setTo(null)}>{t('home.cancel')}</button></p>}
      {err && <p className="err">{t('auth.errors.generic')}</p>}
      <div className="row"><input style={{ flex: 1, background: 'var(--card)', border: '1px solid var(--line)', borderRadius: 999, padding: '10px 14px', textAlign: 'start' }} dir="auto" value={text} maxLength={1000} placeholder={t('home.commentPh')} onChange={e => setText(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} /><button className="ghost" onClick={send} disabled={busy}>{t('home.send')}</button></div>
    </div><BottomNav /></div>);
}
export default function Page() { return <AuthGuard><Comments /></AuthGuard>; }
