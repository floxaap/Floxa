'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import type { QueryDocumentSnapshot } from 'firebase/firestore';
import AuthGuard, { useUser } from '@/components/AuthGuard'; import BottomNav from '@/components/BottomNav'; import Stories from '@/components/Stories'; import PostCard from '@/components/PostCard';
import NotifBell from '@/components/NotifBell'; import { fetchPosts, fetchStories, likedByMe, Post, Story } from '@/lib/feed'; import { useI18n } from '@/i18n';
function Feed() {
  const { t } = useI18n(); const u = useUser();
  const [posts, setPosts] = useState<Post[]>([]); const [liked, setLiked] = useState<Set<string>>(new Set()); const [stories, setStories] = useState<Story[]>([]);
  const [state, setState] = useState<'loading' | 'ok' | 'error'>('loading'); const cursor = useRef<QueryDocumentSnapshot | undefined>(); const done = useRef(false); const more = useRef<HTMLDivElement>(null); const busy = useRef(false);
  const load = useCallback(async () => {
    if (busy.current || done.current) return; busy.current = true;
    try { const r = await fetchPosts(cursor.current); cursor.current = r.cursor; if (!r.cursor) done.current = true;
      const l = await likedByMe(u.uid, r.posts.map(p => p.id)); setLiked(s => new Set([...s, ...l])); setPosts(p => [...p, ...r.posts]); setState('ok');
    } catch { setState('error'); } finally { busy.current = false; }
  }, [u.uid]);
  useEffect(() => { load(); fetchStories().then(setStories).catch(() => {}); }, [load]);
  useEffect(() => { const el = more.current; if (!el) return; const io = new IntersectionObserver(e => e[0].isIntersecting && load(), { rootMargin: '400px' }); io.observe(el); return () => io.disconnect(); }, [load, state]);
  return (<div className="shell">
    <header className="top"><span className="logo">FLOXAAP</span><NotifBell /></header>
    <Stories stories={stories} />
    {state === 'loading' && [0, 1].map(i => <div key={i} className="card" style={{ blockSize: 280, opacity: .5 }} />)}
    {state === 'error' && <p className="err" style={{ padding: 16 }}>{t('auth.errors.generic')} <button className="ghost" onClick={() => { setState('loading'); load(); }}>{t('common.retry')}</button></p>}
    {state === 'ok' && posts.length === 0 && <p className="sub" style={{ padding: 24 }}>{t('home.empty')}</p>}
    {posts.map(p => <PostCard key={p.id} post={p} liked0={liked.has(p.id)} />)}
    <div ref={more} style={{ blockSize: 1 }} /><BottomNav />
  </div>);
}
export default function Home() { return <AuthGuard><Feed /></AuthGuard>; }
