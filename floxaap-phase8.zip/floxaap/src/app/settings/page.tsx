'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link'; import { useRouter } from 'next/navigation';
import { deleteUser, EmailAuthProvider, reauthenticateWithCredential, sendPasswordResetEmail } from 'firebase/auth'; import { deleteDoc, doc, getDoc, updateDoc } from 'firebase/firestore';
import AuthGuard, { useUser } from '@/components/AuthGuard'; import BottomNav from '@/components/BottomNav'; import { auth, db } from '@/lib/firebase'; import { useI18n } from '@/i18n';
type S = { private?: boolean; online?: boolean; lastSeen?: boolean; notif?: Record<string, boolean>; reduceMotion?: boolean };
function Toggle({ label, on, set }: { label: string; on: boolean; set: (v: boolean) => void }) {
  return <button className="row" role="switch" aria-checked={on} onClick={() => set(!on)} style={{ inlineSize: '100%', justifyContent: 'space-between', padding: '12px 16px' }}><span>{label}</span><span style={{ inlineSize: 44, blockSize: 26, borderRadius: 13, background: on ? 'var(--em-a)' : 'var(--elev)', border: '1px solid var(--line)', position: 'relative' }}><i style={{ position: 'absolute', insetBlockStart: 2, insetInlineStart: on ? 20 : 2, inlineSize: 20, blockSize: 20, borderRadius: 10, background: 'var(--tx)', transition: 'inset-inline-start .15s' }} /></span></button>;
}
function Settings() {
  const { t } = useI18n(); const u = useUser(); const r = useRouter(); const [s, setS] = useState<S>({}); const [msg, setMsg] = useState(''); const [err, setErr] = useState(''); const [del, setDel] = useState(false); const [pw, setPw] = useState('');
  useEffect(() => { getDoc(doc(db, 'users', u.uid)).then(x => setS(x.data()?.settings ?? {})).catch(() => {}); try { setS(p => ({ ...p, reduceMotion: localStorage.getItem('floxaap.motion') === 'reduce' })); } catch {} }, [u.uid]);
  async function put(path: string, v: boolean, apply: (s: S) => S) { const prev = s; setS(apply(s)); setErr(''); try { await updateDoc(doc(db, 'users', u.uid), { ['settings.' + path]: v }); } catch { setS(prev); setErr(t('settings.saveFail')); } }
  const motion = (v: boolean) => { setS({ ...s, reduceMotion: v }); try { localStorage.setItem('floxaap.motion', v ? 'reduce' : 'full'); } catch {} document.documentElement.dataset.motion = v ? 'reduce' : 'full'; };
  async function remove() { try { const user = auth.currentUser!; await reauthenticateWithCredential(user, EmailAuthProvider.credential(user.email!, pw));
      const un = (await getDoc(doc(db, 'users', user.uid))).data()?.username; if (un) await deleteDoc(doc(db, 'usernames', un)); await deleteDoc(doc(db, 'users', user.uid)); await deleteUser(user); r.replace('/'); } catch { setErr(t('settings.deleteFail')); } }
  const sec = (k: string) => <h2 className="sub" style={{ padding: '16px 16px 4px' }}>{t('settings.' + k)}</h2>;
  const n = (k: string) => <Toggle key={k} label={t('settings.' + k)} on={s.notif?.[k] !== false} set={v => put('notif.' + k, v, x => ({ ...x, notif: { ...x.notif, [k]: v } }))} />;
  return (<div className="shell"><header className="top"><h1 style={{ fontSize: '1.2rem' }}>{t('settings.title')}</h1></header>
    {err && <p className="err" role="alert" style={{ padding: '0 16px' }}>{err}</p>}{msg && <p className="ok" style={{ padding: '0 16px' }}>{msg}</p>}
    {sec('account')}<p style={{ padding: '4px 16px' }} dir="ltr"><span className="sub">{t('settings.email')}: </span>{u.email}</p>
    <button className="ghost" onClick={() => sendPasswordResetEmail(auth, u.email!).then(() => setMsg(t('settings.resetSent'))).catch(() => setErr(t('auth.errors.generic')))}>{t('settings.changePassword')}</button>
    {sec('privacy')}
    <Toggle label={t('settings.privateAccount')} on={!!s.private} set={v => put('private', v, x => ({ ...x, private: v }))} /><Toggle label={t('settings.showOnline')} on={s.online !== false} set={v => put('online', v, x => ({ ...x, online: v }))} /><Toggle label={t('settings.showLastSeen')} on={s.lastSeen !== false} set={v => put('lastSeen', v, x => ({ ...x, lastSeen: v }))} />
    <p className="sub" style={{ padding: '0 16px' }}>{t('settings.hint')}</p>
    {sec('notifs')}{['likes', 'comments', 'follows', 'calls'].map(n)}
    {sec('appearance')}<Toggle label={t('settings.reduceMotion')} on={!!s.reduceMotion} set={motion} /><Link href="/settings/language" className="ghost" style={{ display: 'block' }}>{t('settings.language')}</Link>
    <div style={{ padding: 16 }}>{!del ? <button className="err" onClick={() => setDel(true)}>{t('settings.deleteAccount')}</button> : <div style={{ display: 'grid', gap: 8 }}><p className="err">{t('settings.deleteWarn')}</p><input type="password" dir="auto" value={pw} placeholder={t('settings.passwordPh')} onChange={e => setPw(e.target.value)} style={{ background: 'var(--card)', border: '1px solid var(--line)', borderRadius: 12, padding: 10, textAlign: 'start' }} /><button className="gold-btn" style={{ background: '#c0392b', color: '#fff', border: 0 }} onClick={remove}>{t('settings.deleteAccount')}</button></div>}</div>
    <BottomNav /></div>);
}
export default function Page() { return <AuthGuard><Settings /></AuthGuard>; }
