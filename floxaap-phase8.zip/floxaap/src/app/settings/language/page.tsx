'use client';
import BottomNav from '@/components/BottomNav'; import { useI18n, Lang } from '@/i18n';
export default function LanguagePage() {
  const { t, lang, setLang } = useI18n();
  const opt = (l: Lang, label: string) => (<button key={l} className="card row" style={{ inlineSize: 'calc(100% - 24px)', padding: 16, justifyContent: 'space-between', borderColor: lang === l ? 'var(--gold-l)' : undefined }} aria-pressed={lang === l} onClick={() => setLang(l)}><span lang={l}>{label}</span>{lang === l && <span style={{ color: 'var(--gold-l)' }}>✓</span>}</button>);
  return (<div className="shell"><header className="top"><h1 style={{ fontSize: '1.2rem' }}>{t('common.language')}</h1></header>{opt('ar', 'العربية')}{opt('en', 'English')}<p className="sub" style={{ padding: '8px 16px' }}>{t('common.langHint')}</p><BottomNav /></div>);
}
