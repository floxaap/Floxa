'use client';
import AuthGuard, { useUser } from '@/components/AuthGuard'; import ProfileView from '@/components/ProfileView';
function Me() { return <ProfileView uid={useUser().uid} />; }
export default function Page() { return <AuthGuard><Me /></AuthGuard>; }
