'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link'; import { collection, limit, onSnapshot, orderBy, query, Timestamp, where, writeBatch, doc, getDoc } from 'firebase/firestore';
import AuthGuard, { useUser } from '@/components/AuthGuard'; import BottomNav from '@/components/BottomNav';
import { db } from '@/lib/firebase'; import { useI18n } from '@/i18n';
type N = { id: string; type: 'follow' | 'like' | 'comment' | 'call'; fromUsername: string; postId: string | null; read: boolean; createdAt: Date };
function Page_() {
  const { t, relTime } = useI18n(); const u = useUser(); const [list, setList] = useState<N[]>([]); const [off, setOff] = useState<string[]>([]);
  useEffect(() => { getDoc(doc(db, 'users', u.uid)).then(x => { const n = x.data()?.settings?.notif ?? {}; setOff(Object.keys(n).filter(k => n[k] === false)); }).catch(() => {}); }, [u.uid]);
  useEffect(() => onSnapshot(query(collection(db, 'notifications'), where('toUid', '==', u.uid), orderBy('createdAt', 'desc'), limit(50)), s => {
    const rows = s.docs.map(d => { const x = d.data({ serverTimestamps: 'estimate' }); return { ...(x as any), id: d.id, createdAt: (x.createdAt as Timestamp).toDate() } as N; }); setList(rows);
    const un = rows.filter(r => !r.read); if (un.length) { const b = writeBatch(db); un.forEach(r => b.update(doc(db, 'notifications', r.id), { read: true })); b.commit().catch(() => {}); }
  }, () => {}), [u.uid]);
  const map: Record<string, string> = { like: 'likes', comment: 'comments', follow: 'follows', call: 'calls' }; const shown = list.filter(n => !off.includes(map[n.type]));
  return (<div className="shell"><header className="top"><h1 style={{ fontSize: '1.2rem' }}>{t('social.notifications')}</h1></header>
    {shown.length === 0 && <p className="sub" style={{ padding: 24 }}>{t('social.noNotifs')}</p>}
    {shown.map(n => <Link key={n.id} href={n.postId ? '/post/' + n.postId : '/explore'} className="card" style={{ display: 'block', padding: 14, textDecoration: 'none', color: 'inherit', borderColor: n.read ? undefined : 'var(--gold-l)' }}>
      <p dir="auto" style={{ textAlign: 'start' }}>{t('social.n.' + n.type, { name: n.fromUsername })}</p><span className="sub">{relTime(n.createdAt)}</span></Link>)}
    <BottomNav /></div>);
}
export default function Page() { return <AuthGuard><Page_ /></AuthGuard>; }
