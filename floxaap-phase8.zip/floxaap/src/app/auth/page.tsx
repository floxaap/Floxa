'use client';
import { Suspense, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, sendEmailVerification, sendPasswordResetEmail, updateProfile } from 'firebase/auth';
import { doc, runTransaction, serverTimestamp } from 'firebase/firestore';
import { auth, db, configured } from '@/lib/firebase';
import { useI18n } from '@/i18n';

function Form() {
  const { t } = useI18n(); const r = useRouter();
  const [reg, setReg] = useState(useSearchParams().get('mode') === 'register');
  const [f, setF] = useState({ name: '', username: '', email: '', password: '', confirm: '' });
  const [err, setErr] = useState(''); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false);
  const up = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(''); setMsg('');
    if (!configured) return setErr(t('auth.errors.config'));
    if (!f.email || !f.password || (reg && (!f.name || !f.username))) return setErr(t('auth.errors.required'));
    if (reg) {
      if (!/^[a-zA-Z0-9_]{3,20}$/.test(f.username)) return setErr(t('auth.errors.usernameFormat'));
      if (f.password.length < 8) return setErr(t('auth.errors.weak'));
      if (f.password !== f.confirm) return setErr(t('auth.errors.mismatch'));
    }
    setBusy(true);
    try {
      if (reg) {
        const c = await createUserWithEmailAndPassword(auth, f.email, f.password);
        const uname = f.username.toLowerCase();
        try {
          await runTransaction(db, async tx => { // reserves username atomically; rules block overwrite
            const ref = doc(db, 'usernames', uname);
            if ((await tx.get(ref)).exists()) throw new Error('taken');
            tx.set(ref, { uid: c.user.uid }); tx.set(doc(db, 'users', c.user.uid), { name: f.name, username: uname, verified: false, createdAt: serverTimestamp() });
          });
        } catch (x: any) { if (x.message === 'taken') { await c.user.delete(); return setErr(t('auth.errors.usernameTaken')); } throw x; }
        await updateProfile(c.user, { displayName: f.name });
        await sendEmailVerification(c.user); setMsg(t('auth.verifySent'));
      } else await signInWithEmailAndPassword(auth, f.email, f.password);
      r.replace('/home');
    } catch (x: any) {
      setErr(t(x.code === 'auth/email-already-in-use' ? 'auth.errors.emailInUse' : String(x.code).startsWith('auth/invalid') || x.code === 'auth/user-not-found' || x.code === 'auth/wrong-password' ? 'auth.errors.invalid' : 'auth.errors.generic'));
    } finally { setBusy(false); }
  }
  async function reset() { if (!f.email) return setErr(t('auth.errors.required')); try { await sendPasswordResetEmail(auth, f.email); setMsg(t('auth.resetSent')); } catch { setErr(t('auth.errors.generic')); } }
  const F = (k: keyof typeof f, label: string, type = 'text') => (<label className="field"><span className="sub">{t(label)}</span><input type={type} value={f[k]} onChange={up(k)} dir={type === 'text' && k !== 'name' ? 'ltr' : 'auto'} autoComplete={k} /></label>);
  return (
    <main className="shell" style={{ padding: 24 }}>
      <h1 className="logo" style={{ marginBlock: 24 }}>FLOXAAP</h1>
      <form onSubmit={submit}>
        {reg && F('name', 'auth.fullName')}{reg && F('username', 'auth.username')}
        {F('email', 'auth.email', 'email')}{F('password', 'auth.password', 'password')}{reg && F('confirm', 'auth.confirm', 'password')}
        {err && <p className="err" role="alert">{err}</p>}{msg && <p className="ok">{msg}</p>}
        <button className="gold-btn" disabled={busy}>{busy ? t('common.loading') : reg ? t('auth.createAccount') : t('common.signIn')}</button>
      </form>
      <button className="ghost" onClick={() => setReg(!reg)}>{reg ? t('auth.haveAccount') : t('auth.noAccount')}</button>
      {!reg && <button className="ghost" onClick={reset}>{t('auth.forgot')}</button>}
    </main>
  );
}
export default function Page() { return <Suspense><Form /></Suspense>; }
