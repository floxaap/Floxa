'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link'; import { collection, getDocs, limit, orderBy, query, where } from 'firebase/firestore';
import AuthGuard from '@/components/AuthGuard'; import BottomNav from '@/components/BottomNav'; import FollowButton from '@/components/FollowButton';
import { db } from '@/lib/firebase'; import { useI18n } from '@/i18n';
type Tab = 'all' | 'people' | 'photos' | 'videos'; type P = { id: string; media?: string; mediaType?: string; caption: string }; type U = { id: string; name: string; username: string; followersCount?: number };
const H = 'floxaap.searches'; const hist = (): string[] => { try { return JSON.parse(localStorage.getItem(H) || '[]'); } catch { return []; } };
function Explore() {
  const { t, lang } = useI18n(); const [tab, setTab] = useState<Tab>('all'); const [q, setQ] = useState(''); const [posts, setPosts] = useState<P[]>([]); const [users, setUsers] = useState<U[]>([]); const [recent, setRecent] = useState<string[]>([]); const [err, setErr] = useState(false);
  useEffect(() => setRecent(hist()), []);
  useEffect(() => { if (tab === 'people') return; setErr(false);
    const base = [collection(db, 'posts'), ...(tab === 'photos' ? [where('mediaType', '==', 'image')] : tab === 'videos' ? [where('mediaType', '==', 'video')] : []), orderBy('likeCount', 'desc'), limit(18)] as const;
    getDocs(query(...(base as [any, ...any[]]))).then(s => setPosts(s.docs.map(d => ({ id: d.id, ...(d.data() as any) })))).catch(() => setErr(true)); }, [tab]);
  useEffect(() => { const s = q.trim().toLowerCase().replace(/^@/, ''); if (!s) { if (tab === 'people') setUsers([]); return; }
    const h = setTimeout(() => getDocs(query(collection(db, 'users'), orderBy('username'), where('username', '>=', s), where('username', '<=', s + '\uf8ff'), limit(10))).then(r => setUsers(r.docs.map(d => ({ id: d.id, ...(d.data() as any) })))).catch(() => setErr(true)), 250); return () => clearTimeout(h); }, [q, tab]);
  function commit() { const s = q.trim(); if (!s) return; const n = [s, ...hist().filter(x => x !== s)].slice(0, 8); try { localStorage.setItem(H, JSON.stringify(n)); } catch {} setRecent(n); }
  const showUsers = tab === 'people' || q.trim();
  return (<div className="shell"><header className="top"><h1 style={{ fontSize: '1.3rem' }}>{t('social.explore')}</h1></header>
    <div style={{ padding: '0 12px' }}><input dir="auto" value={q} placeholder={t('social.searchPh')} onChange={e => { setQ(e.target.value); if (e.target.value && tab !== 'people') setTab('people'); }} onKeyDown={e => e.key === 'Enter' && commit()} onBlur={commit} style={{ inlineSize: '100%', background: 'var(--card)', border: '1px solid var(--line)', borderRadius: 999, padding: '10px 16px', textAlign: 'start' }} /></div>
    <div className="row" style={{ padding: '10px 12px', overflowX: 'auto' }}>{(['all', 'people', 'photos', 'videos'] as Tab[]).map(k => <button key={k} className={'act' + (tab === k ? ' on' : '')} style={{ border: '1px solid var(--line)', borderRadius: 99, padding: '6px 14px', whiteSpace: 'nowrap' }} aria-pressed={tab === k} onClick={() => setTab(k)}>{t('social.' + k)}</button>)}</div>
    {err && <p className="err" style={{ padding: '0 16px' }}>{t('auth.errors.generic')}</p>}
    {!q && tab === 'people' && recent.length > 0 && <div style={{ padding: '0 16px' }}><p className="sub">{t('social.recent')}</p>{recent.map(r => <button key={r} className="ghost" dir="auto" onClick={() => setQ(r)}>{r}</button>)}<button className="sub" onClick={() => { try { localStorage.removeItem(H); } catch {} setRecent([]); }}>{t('social.clear')}</button></div>}
    {showUsers ? (<>{q && users.length === 0 && <p className="sub" style={{ padding: 16 }}>{t('social.noResults')}</p>}
      {users.map(u => <div key={u.id} className="row" style={{ padding: '10px 16px' }}><Link href={'/profile/' + u.id} className="row" style={{ flex: 1, textDecoration: 'none', color: 'inherit' }}><span className="avatar" style={{ display: 'grid', placeItems: 'center', color: 'var(--gold-l)' }}>{(u.name || '?').slice(0, 1)}</span><div style={{ flex: 1 }}><b dir="auto">{u.name}</b><div className="sub"><span dir="ltr" style={{ unicodeBidi: 'isolate' }}>@{u.username}</span> · {t('social.followers', { n: new Intl.NumberFormat(lang).format(u.followersCount ?? 0) })}</div></div></Link><FollowButton uid={u.id} /></div>)}</>)
      : (<>{posts.length === 0 && !err && <p className="sub" style={{ padding: 16 }}>{t('social.noResults')}</p>}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 2, padding: '0 2px' }}>{posts.map(p => <Link key={p.id} href={'/post/' + p.id} style={{ aspectRatio: '1', background: 'var(--elev)', display: 'grid', placeItems: 'center', overflow: 'hidden', fontSize: '.75rem', padding: 6 }}>
          {p.media ? (p.mediaType === 'video' ? <video src={p.media} muted preload="metadata" style={{ inlineSize: '100%', blockSize: '100%', objectFit: 'cover' }} /> : <img src={p.media} alt="" loading="lazy" style={{ inlineSize: '100%', blockSize: '100%', objectFit: 'cover' }} />) : <span dir="auto">{p.caption.slice(0, 60)}</span>}</Link>)}</div></>)}
    <BottomNav /></div>);
}
export default function Page() { return <AuthGuard><Explore /></AuthGuard>; }
